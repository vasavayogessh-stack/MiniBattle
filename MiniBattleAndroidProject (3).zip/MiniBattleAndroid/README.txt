MINI BATTLE ANDROID - starter prototype

Features:
- Native Android 2D canvas game.
- Landscape touch controls.
- Unlimited firing visual effect and jetpack-style upward movement.
- Basic TCP host/join multiplayer over the same Wi-Fi/hotspot (prototype).

Build:
- Open this folder in Android Studio / AndroidIDE as a Gradle project.
- Use JDK 17 and Android SDK platform 35.
- Build: gradle assembleDebug
- APK output: app/build/outputs/apk/debug/app-debug.apk

LAN notes:
- Start HOST GAME on one phone.
- Find that phone's local Wi-Fi IP address in Android Wi-Fi details.
- On second phone, enter that IP and tap JOIN.
- Both phones must be on the same Wi-Fi/hotspot network.
- This is an early prototype, not a polished commercial game. Multiplayer sync is basic.
