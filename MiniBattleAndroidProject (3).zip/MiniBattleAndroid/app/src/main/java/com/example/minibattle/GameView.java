package com.example.minibattle;

import android.content.Context;
import android.graphics.*;
import android.view.*;
import java.net.*;
import java.io.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class GameView extends View {
    Paint p = new Paint(3);
    float x=180,y=260,vx=0,vy=0, otherX=520,otherY=260;
    boolean left=false,right=false,up=false,shoot=false;
    long lastShot=0;
    volatile String role="offline";
    ServerSocket server;
    Socket socket;
    PrintWriter out;
    BufferedReader in;
    Thread netThread;
    AtomicBoolean running=new AtomicBoolean(false);
    int worldW=1000, worldH=600;
    public GameView(Context c){super(c); setFocusable(true);}
    void startHost(){
        stopNetwork(); role="host"; running.set(true);
        netThread=new Thread(()->{
            try {
                server=new ServerSocket(45678);
                Socket s=server.accept(); socket=s;
                setupStreams(s);
                readLoop();
            } catch(Exception e){ postInvalidate(); }
        }); netThread.start();
    }
    void join(String host){
        stopNetwork(); role="client"; running.set(true);
        netThread=new Thread(()->{
            try {
                Socket s=new Socket(); s.connect(new InetSocketAddress(host,45678),7000); socket=s;
                setupStreams(s); readLoop();
            } catch(Exception e){ role="offline"; postInvalidate(); }
        }); netThread.start();
    }
    void setupStreams(Socket s)throws Exception{
        out=new PrintWriter(new BufferedWriter(new OutputStreamWriter(s.getOutputStream())),true);
        in=new BufferedReader(new InputStreamReader(s.getInputStream()));
    }
    void readLoop(){
        try {
            String line;
            while(running.get() && (line=in.readLine())!=null){
                String[] a=line.split(",");
                if(a.length>=2){ otherX=Float.parseFloat(a[0]); otherY=Float.parseFloat(a[1]); }
                if(role.equals("host") && out!=null) out.println(x+","+y);
                postInvalidate();
            }
        } catch(Exception ignored){} finally { role="offline"; }
    }
    void stopNetwork(){
        running.set(false);
        try{if(socket!=null)socket.close();}catch(Exception e){}
        try{if(server!=null)server.close();}catch(Exception e){}
        socket=null; server=null; out=null; in=null;
    }
    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        float sx=getWidth()/1000f, sy=getHeight()/600f;
        c.save(); c.scale(sx,sy);
        c.drawColor(Color.rgb(120,190,235));
        p.setColor(Color.rgb(75,145,70)); c.drawRect(0,530,1000,600,p);
        p.setColor(Color.rgb(90,95,110)); c.drawRect(300,430,650,455,p);
        p.setColor(Color.rgb(70,75,90)); c.drawRect(80,350,250,375,p);
        // player
        p.setColor(Color.rgb(35,80,220)); c.drawCircle(x,y,22,p);
        p.setColor(Color.WHITE); c.drawCircle(x+7,y-5,4,p);
        // opponent
        p.setColor(Color.rgb(220,55,55)); c.drawCircle(otherX,otherY,22,p);
        p.setColor(Color.WHITE); c.drawCircle(otherX+7,otherY-5,4,p);
        // bullets are unlimited; visual tracer
        p.setColor(Color.YELLOW);
        if(shoot) c.drawRect(x+20,y-4,Math.min(980,x+160),y+4,p);
        p.setColor(Color.WHITE); p.setTextSize(22);
        c.drawText("Mini Battle  |  " + role + "  |  Unlimited bullets + jetpack",20,32,p);
        c.drawText("MOVE: ◀ ▶     FLY: ▲     FIRE: ●",20,65,p);
        c.restore();
        updateGame();
        postInvalidateDelayed(16);
    }
    void updateGame(){
        if(left)x-=4; if(right)x+=4; if(up)y-=5; else if(y<500)y+=2;
        x=Math.max(25,Math.min(975,x)); y=Math.max(70,Math.min(505,y));
        if(out!=null && running.get() && System.currentTimeMillis()-lastShot>45){
            lastShot=System.currentTimeMillis();
            out.println(x+","+y);
        }
    }
    @Override public boolean onTouchEvent(android.view.MotionEvent e){
        float xx=e.getX()*1000f/Math.max(1,getWidth()), yy=e.getY()*600f/Math.max(1,getHeight());
        int action=e.getActionMasked();
        if(action==MotionEvent.ACTION_UP){left=right=up=shoot=false; return true;}
        if(action==MotionEvent.ACTION_DOWN || action==MotionEvent.ACTION_MOVE){
            left=xx<180 && yy>380;
            right=xx>=180 && xx<360 && yy>380;
            up=xx>=360 && xx<560 && yy>380;
            shoot=xx>=560 && yy>380;
            if(shoot){ lastShot=0; }
            return true;
        }
        return true;
    }
}
