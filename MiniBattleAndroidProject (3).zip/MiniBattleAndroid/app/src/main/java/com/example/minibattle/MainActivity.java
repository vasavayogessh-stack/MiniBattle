package com.example.minibattle;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import android.text.InputType;

public class MainActivity extends Activity {
    GameView game;
    EditText ip;
    TextView status;
    LinearLayout root;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(12,12,12,12);
        root.setBackgroundColor(Color.rgb(22,28,40));
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        Button host = new Button(this); host.setText("HOST GAME");
        Button join = new Button(this); join.setText("JOIN");
        ip = new EditText(this); ip.setSingleLine(true); ip.setText("192.168.");
        ip.setHint("Host IP"); ip.setTextColor(Color.WHITE); ip.setHintTextColor(Color.LTGRAY);
        ip.setInputType(InputType.TYPE_CLASS_PHONE);
        status = new TextView(this); status.setTextColor(Color.WHITE); status.setText("Same Wi-Fi/hotspot par dono phone rakho.");
        bar.addView(host, new LinearLayout.LayoutParams(0, -2, 1));
        bar.addView(join, new LinearLayout.LayoutParams(0, -2, 1));
        bar.addView(ip, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(bar);
        root.addView(status);
        game = new GameView(this);
        root.addView(game, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        host.setOnClickListener(v -> { game.startHost(); status.setText("Host chalu. Dusre phone me host ka IP daal kar JOIN karo."); });
        join.setOnClickListener(v -> { game.join(ip.getText().toString().trim()); status.setText("Connect karne ki koshish..."); });
    }
    @Override protected void onPause(){ super.onPause(); if(game!=null) game.stopNetwork(); }
}
