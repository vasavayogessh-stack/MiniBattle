MINI BATTLE LAN (prototype)
===========================
Features: local Wi-Fi/hotspot multiplayer, touch controls, unlimited firing, unlimited jetpack fuel.

HOST SETUP
1. Install Node.js 18+ on a laptop/PC connected to the same Wi-Fi/hotspot as the phones.
2. Open a terminal in this folder and run:
   npm install ws
   node server.js
3. Find the laptop/PC's local IPv4 address (Windows: ipconfig; Android hotspot host: check hotspot details).
4. On each phone, open http://HOST-IP:3000 in Chrome.
5. Enter the host IP in the Host IP field (example 192.168.1.5:3000), use the same room code, then tap Connect.

IMPORTANT
- This is an early playable prototype, not a finished Mini Militia clone.
- A host computer running the server is required; phones must be on the same Wi-Fi/hotspot.
- Keep the server running while playing. Allow Node.js through the local network firewall.
- Internet is not required. All players should use the same room code.
