// Mini Battle LAN server - Node.js 18+
const http=require('http');
const WebSocket=require('ws');
const fs=require('fs');
const path=require('path');
const server=http.createServer((req,res)=>{
 const file=path.join(__dirname,'public',req.url==='/'?'index.html':req.url);
 fs.readFile(file,(err,data)=>{if(err){res.writeHead(404);return res.end('Not found')}
 res.writeHead(200,{'Content-Type':file.endsWith('.html')?'text/html':'text/plain'});res.end(data)});
});
const wss=new WebSocket.Server({server});
let clients=new Map(),bullets=[],next=1;
function state(){let players={};for(const [id,p] of clients)players[id]=p.data;
 const msg=JSON.stringify({type:'state',players,bullets});
 for(const [id,p] of clients)if(p.ws.readyState===1)p.ws.send(msg)}
wss.on('connection',ws=>{
 const id=String(next++),p={ws,data:{id,x:120+Math.random()*250,y:220,face:1,name:'Player'}};
 clients.set(id,p);
 ws.on('message',raw=>{let m;try{m=JSON.parse(raw)}catch{return}
 if(m.type==='join'){p.data.name=String(m.name||'Player').slice(0,12);p.room=String(m.room||'BATTLE').slice(0,16);ws.send(JSON.stringify({type:'welcome',id,players:Object.fromEntries([...clients].map(([k,v])=>[k,v.data]))}))}
 if(m.type==='move'){p.data.x=Number(m.x)||p.data.x;p.data.y=Number(m.y)||p.data.y;p.data.face=m.face<0?-1:1;p.data.name=String(m.name||p.data.name).slice(0,12)}
 if(m.type==='shoot'){bullets.push({x:Number(m.x)||0,y:Number(m.y)||0,vx:(m.face<0?-1:1)*12,owner:id,life:70})}
 });
 ws.on('close',()=>clients.delete(id));
});
setInterval(()=>{for(const b of bullets){b.x+=b.vx;b.life--}bullets=bullets.filter(b=>b.life>0);state()},50);
server.listen(3000,'0.0.0.0',()=>console.log('Open http://YOUR-HOST-IP:3000'));
